export class Emp{
    id:number;
    name:string;
    salary:number;
    
}