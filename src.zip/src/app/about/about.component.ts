import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Emp } from '../employee';
import { formArrayNameProvider } from '@angular/forms/src/directives/reactive_directives/form_group_name';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})


export class AboutComponent implements OnInit {
name:string;
salary:number;

emplist:Array<Emp>=[];
showUpdate:boolean=false;




  constructor(private service:EmployeeService) { 
this.emplist=service.employeelist;

  }


  ngOnInit() {
    this.emplist=this.service.employeelist;
  }
  delele(id){
    this.service.deleteEmploye(id);
  }
  updateShow(e:Emp){
    this.showUpdate=true;
    this.name=e.name;
    this.salary=e.salary;
  }

  update(f:NgForm){
     console.log( f.value);
  }
}
