export const environment = {
  production: true,
  api_url: 'https://conduit.productionready.io/api'
};
