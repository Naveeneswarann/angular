import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ListuserComponent } from './listuser/listuser.component';
import { AdduserComponent } from './adduser/adduser.component';
import { EdituserComponent } from './edituser/edituser.component';

const routes:Routes=[
    {path: 'login',component: LoginComponent},
    {path: 'adduser',component: AdduserComponent},
    {path: 'listuser',component: ListuserComponent},
    {path: 'edituser',component: EdituserComponent},
    {path: '',component: LoginComponent}

];
export const routing=RouterModule.forRoot(routes);