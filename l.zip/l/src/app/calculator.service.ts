import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalculatorService {

  constructor() { }
  add(a,b) : number{
    let c =parseInt(a)+parseInt(b);
    return c;
  }
  sub(a,b) : number{
    let c =parseInt(a)-parseInt(b);
    return c;
  }
}
