import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'fact'
})
export class FactPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    var i;
    var factorial =1;
    for(i=1;i<=value;i++)
    {
      factorial*=i;
    }
    return factorial;
  }

}
