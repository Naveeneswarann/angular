export class Employee
{
    employeeId : number;
    employeeName : string;
    employeeSalary : number;
    
}